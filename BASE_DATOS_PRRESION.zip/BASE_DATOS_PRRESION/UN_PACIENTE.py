import serial
import time
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.signal import find_peaks
import os

# Configuración del puerto serial y la velocidad de baudios
PUERTO = 'COM14'  # Ajusta este valor según el puerto en el que está conectado tu Arduino
BAUDIOS = 9600
ser = serial.Serial(PUERTO, BAUDIOS, timeout=1)

# Parámetros de detección de la presión
VALOR_MAXIMO_SENSOR = 122.35
UMBRAL_ESTABILIDAD = 0.5
TIEMPO_ESTABILIZACION = 2
VALOR_MINIMO_DESINFLADO = 14

# Función para enviar mensajes al Arduino
def enviar_a_arduino(mensaje):
    ser.write(f"{mensaje}\n".encode())

# Función para obtener el nombre del paciente
def obtener_nombre_paciente():
    return input("Ingrese el nombre del paciente: ")

# Función para diagnosticar la presión arterial
def diagnosticar_presion(presion_sistolica, presion_diastolica):
    if presion_sistolica < 120 and presion_diastolica < 80:
        return "Normal"
    elif 120 <= presion_sistolica < 130 and presion_diastolica < 80:
        return "Elevada"
    elif 130 <= presion_sistolica < 140 or 80 <= presion_diastolica < 90:
        return "Hipertensión (Estadio 1)"
    elif presion_sistolica >= 140 or presion_diastolica >= 90:
        return "Hipertensión (Estadio 2)"
    elif presion_sistolica > 180 or presion_diastolica > 120:
        return "Crisis hipertensiva"
    else:
        return "Hipotensión"

# Función principal para medir la presión arterial
def medir_presion():
    datos_presion = []
    tiempos = []
    estabilizado = False
    tiempo_inicio_estabilizacion = None
    inicio_medicion = time.time()

    enviar_a_arduino("BIENVENIDO :)")

    while True:
        if ser.in_waiting:
            dato = ser.readline().decode('utf-8').strip()
            try:
                valor = float(dato)
                tiempo_actual = time.time() - inicio_medicion
                datos_presion.append(valor)
                tiempos.append(tiempo_actual)

                if not estabilizado and valor >= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                    if tiempo_inicio_estabilizacion is None:
                        tiempo_inicio_estabilizacion = tiempo_actual
                        enviar_a_arduino("Comenzando a inflar...")
                    elif tiempo_actual - tiempo_inicio_estabilizacion >= TIEMPO_ESTABILIZACION:
                        estabilizado = True
                        enviar_a_arduino("Valor máximo estabilizado.")

                if estabilizado and valor <= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                    break

            except ValueError as e:
                print(f"Error al convertir el dato: {e}")

    enviar_a_arduino("Desinflando...")
    while True:
        if ser.in_waiting:
            dato = ser.readline().decode('utf-8').strip()
            try:
                valor = float(dato)
                tiempo_actual = time.time() - inicio_medicion
                datos_presion.append(valor)
                tiempos.append(tiempo_actual)

                if valor <= VALOR_MINIMO_DESINFLADO:
                    enviar_a_arduino("Desinflado completado.")
                    break

            except ValueError as e:
                print(f"Error al convertir el dato: {e}")

    # Procesamiento de los datos para la detección de picos
    derivada_presion = np.diff(datos_presion) / np.diff(tiempos)
    derivada_presion = np.insert(derivada_presion, 0, 0)
    picos_derivada, _ = find_peaks(abs(derivada_presion), height=np.std(derivada_presion))

    try:
        if tiempo_inicio_estabilizacion is not None:
            picos_derivada = [p for p in picos_derivada if tiempos[p] >= tiempo_inicio_estabilizacion + TIEMPO_ESTABILIZACION]

            if len(picos_derivada) > 0:
                pico_sistolico = picos_derivada[0]
                presion_sistolica = datos_presion[pico_sistolico]
                tiempo_pico_sistolico = tiempos[pico_sistolico]
                mensaje_presion = f"Presión sist: {presion_sistolica:.2f} mmHg"
                print(mensaje_presion)
                enviar_a_arduino(mensaje_presion)
                presion_diastolica = presion_sistolica * 0.67
                mensaje_diastolica = f"Presión diasT: {presion_diastolica:.2f} mmHg"
                print(mensaje_diastolica)
                enviar_a_arduino(mensaje_diastolica)

                # Diagnóstico de la presión arterial
                diagnostico = diagnosticar_presion(presion_sistolica, presion_diastolica)
                print(f"Diagnóstico: {diagnostico}")

                # Guardar los datos del paciente
                nombre_paciente = obtener_nombre_paciente()
                return {
                    "Nombre": nombre_paciente,
                    "Presión Sist (mmHg)": presion_sistolica,
                    "Presión DiasT (mmHg)": presion_diastolica,
                    "Diagnóstico": diagnostico
                }
            else:
                mensaje_error = "No se detecta presión sistólica"
                print(mensaje_error)
                enviar_a_arduino(mensaje_error)
    finally:
        # Graficar los resultados
        plt.figure(figsize=(10, 6))
        plt.plot(tiempos, datos_presion, label='Medida durante desinflado', color='blue')
        if len(picos_derivada) > 0:
            plt.scatter(tiempo_pico_sistolico, presion_sistolica, color='red', label='Pico Sistólico')
        plt.title('Medición de Presión')
        plt.xlabel('Tiempo (s)')
        plt.ylabel('Presión (mmHg)')
        plt.legend()
        plt.grid(True)
        plt.show()

# Realizar la medición y guardar el resultado en Excel
try:
    datos_paciente = medir_presion()
    df_paciente = pd.DataFrame([datos_paciente])
    ruta_escritorio = os.path.join(os.path.expanduser("~"), "Desktop", "diagnostico_paciente.xlsx")
    df_paciente.to_excel(ruta_escritorio, index=False)
    print(f"Diagnóstico guardado en: {ruta_escritorio}")
finally:
    ser.close()
