import serial
import pandas as pd
import matplotlib.pyplot as plt
import os
import time

# Configura el puerto serial y la velocidad de baudios
ser = serial.Serial('COM14', 9600)

# Umbral para detectar el cambio drástico (ajusta este valor según sea necesario)
UMBRAL_CAMBIO = 0.5
# Tiempo en segundos para detectar un cambio drástico
TIEMPO_PARA_CAMBIO = 1.2
# Tiempo en segundos para tomar cada medida
DURACION_MEDIDA = 38


# Función para detectar un cambio drástico en la presión y recolectar datos
def recolectar_datos(umbral_cambio, tiempo_para_cambio, duracion):
    datos = []
    tiempos = []
    cambio_detectado = False
    valor_anterior = None
    start_time = None

    while True:
        if ser.in_waiting:
            line = ser.readline()
            try:
                valor_actual = float(line.decode('utf-8').strip())
                tiempo_actual = time.time()

                if not cambio_detectado:
                    if valor_anterior is None:
                        valor_anterior = valor_actual
                    elif abs(valor_actual - valor_anterior) >= umbral_cambio:
                        # Registra el tiempo cuando se detecta un cambio drástico
                        start_time = tiempo_actual - tiempo_para_cambio
                        cambio_detectado = True
                        print("Cambio drástico detectado. Comenzando la recolección de datos...")

                if cambio_detectado:
                    datos.append(valor_actual)
                    tiempos.append(tiempo_actual - start_time)
                    if tiempo_actual - start_time >= duracion:
                        break
                else:
                    valor_anterior = valor_actual

            except ValueError:
                print("No se pudo convertir el dato a un valor flotante.")

    return tiempos, datos


# Recolecta datos para 3 medidas diferentes
mediciones = []

for i in range(1, 4):
    print(f"Iniciando medición {i}...")
    tiempos, datos = recolectar_datos(UMBRAL_CAMBIO, TIEMPO_PARA_CAMBIO, DURACION_MEDIDA)
    medicion_df = pd.DataFrame({
        f'Medida_{i}_Tiempo': tiempos,
        f'Medida_{i}_Valor': datos
    })
    mediciones.append(medicion_df)
    plt.plot(tiempos, datos, label=f'Medida {i}')

# Combina los DataFrames de cada medición
mediciones_df = pd.concat(mediciones, axis=1)

# Cierra el puerto serial
ser.close()

# Guarda los datos en un archivo de Excel
desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
ruta_excel = os.path.join(desktop, 'resultados_medicion.xlsx')
mediciones_df.to_excel(ruta_excel, index=False)

# Configura y muestra la gráfica
plt.xlabel('Tiempo (s)')
plt.ylabel('Presión')
plt.title('Medición de Presión')
plt.legend()
plt.grid(True)
plt.show()

print(f"Datos guardados en: {ruta_excel}")
