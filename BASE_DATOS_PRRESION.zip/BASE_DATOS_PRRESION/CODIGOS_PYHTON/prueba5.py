import serial
import matplotlib.pyplot as plt
import time
import os

# Configura el puerto serial y la velocidad de baudios
ser = serial.Serial('COM14', 9600)  # Cambia a tu puerto correcto

# Establece el tiempo de recolección de datos
tiempo_recoleccion = 10
datos = []
tiempos = []

start_time = time.time()

try:
    # Recolecta datos durante 10 segundos
    while time.time() - start_time < tiempo_recoleccion:
        if ser.in_waiting:
            line = ser.readline()
            try:
                # Decodifica y convierte en número flotante
                dato = float(line.decode('utf-8').strip())
                # Guarda el dato y el tiempo relativo desde el inicio de la recolección
                datos.append(dato)
                tiempos.append(time.time() - start_time)
            except ValueError:
                print("No se pudo convertir el dato a un valor flotante")

finally:
    # Cierra el puerto serial
    ser.close()

# Consigue la ruta del escritorio del usuario actual
desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')

# Ruta para guardar el archivo en el escritorio
ruta_archivo = os.path.join(desktop, 'datos_sensor.txt')

# Guarda los datos en un archivo (opcional)
with open(ruta_archivo, 'w') as f:
    for t, val in zip(tiempos, datos):
        f.write(f"{t},{val}\n")

# Crea la gráfica
plt.figure(figsize=(10, 5))
plt.plot(tiempos, datos, color='blue', linestyle='-', marker='o', markersize=4)
plt.title('Datos del Sensor en 10 Segundos')
plt.xlabel('Tiempo (s)')
plt.ylabel('Valor del Sensor')
plt.grid(True)
plt.show()
