import serial
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import time
from scipy.signal import find_peaks, butter, filtfilt

# Configuración del puerto serial y la velocidad de baudios
PUERTO = 'COM14'  # Ajusta al puerto correcto
BAUDIOS = 9600
ser = serial.Serial(PUERTO, BAUDIOS)

# Parámetros de detección de la presión
UMBRAL_CAMBIO = 0.5
TIEMPO_PARA_CAMBIO = 1.2  # El tiempo durante el cual debe mantenerse el cambio para considerarse drástico
DURACION_MEDIDA = 38

# Procesamiento de los datos en tiempo real
def recolectar_datos(ser, duracion_medida):
    datos = []
    tiempos = []
    cambio_detectado = False
    tiempo_inicio_cambio = None
    start_time = time.time()

    while True:
        if ser.in_waiting:
            line = ser.readline()
            try:
                valor_actual = float(line.decode('utf-8').strip())
                tiempo_actual = time.time() - start_time
                datos.append(valor_actual)
                tiempos.append(tiempo_actual)

                # Detectar un cambio drástico
                if not cambio_detectado and len(datos) > 1:
                    if abs(datos[-1] - datos[-2]) >= UMBRAL_CAMBIO:
                        if tiempo_inicio_cambio is None:
                            tiempo_inicio_cambio = tiempo_actual
                        elif tiempo_actual - tiempo_inicio_cambio >= TIEMPO_PARA_CAMBIO:
                            cambio_detectado = True
                            print("Cambio drástico detectado. Comenzando la recolección de datos...")
                    else:
                        tiempo_inicio_cambio = None  # Resetear si el cambio no se mantiene

                # Si ya pasó la duración de medida, detener la recolección
                if tiempo_actual >= duracion_medida:
                    break

            except ValueError:
                print("No se pudo convertir el dato a un valor flotante.")

    return tiempos, datos

# Función para aplicar un filtro de suavizado y detectar la presión sistólica
def detectar_presion_sistolica(tiempos, datos):
    # Aplicar un filtro de suavizado
    b, a = butter(N=3, Wn=0.05, btype='low')
    datos_filtrados = filtfilt(b, a, datos)

    # Detectar picos en el intervalo de desinflado
    picos, _ = find_peaks(datos_filtrados, height=None)
    if picos.size > 0:
        indice_pico_sistolico = picos[np.argmax(datos_filtrados[picos])]
        presion_sistolica = datos_filtrados[indice_pico_sistolico]
        tiempo_pico_sistolico = tiempos[indice_pico_sistolico]
        return presion_sistolica, tiempo_pico_sistolico
    else:
        return None, None

# Realizar las mediciones
for i in range(1, 4):
    print(f"Iniciando medición {i}...")
    tiempos, datos = recolectar_datos(ser, DURACION_MEDIDA)
    presion_sistolica, tiempo_pico_sistolico = detectar_presion_sistolica(tiempos, datos)

    # Graficar los resultados
    plt.plot(tiempos, datos, label=f'Medida {i}')
    if presion_sistolica is not None:
        plt.scatter(tiempo_pico_sistolico, presion_sistolica, color='red', label=f'Pico Sistólica {i}')
        print(f"Presión Sistólica Medida {i}: {presion_sistolica:.2f}")

# Configuración final de la gráfica
plt.xlabel('Tiempo (s)')
plt.ylabel('Presión')
plt.title('Medición de Presión')
plt.legend()
plt.grid(True)
plt.show()

# Cerrar el puerto serial
ser.close()
