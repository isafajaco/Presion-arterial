import serial
import time
from scipy.signal import find_peaks
import numpy as np

# Configuración del puerto serial y la velocidad de baudios
PUERTO = 'COM13'  # Ajusta este valor según el puerto en el que está conectado tu Arduino
BAUDIOS = 9600
ser = serial.Serial(PUERTO, BAUDIOS, timeout=1)

# Función para enviar mensajes al Arduino
def enviar_a_arduino(mensaje):
    ser.write(f"{mensaje}\n".encode())

# Función de diagnóstico según la OMS
def diagnostico_oms(sistolica, diastolica):
    if sistolica < 90 or diastolica < 60:
        return "Estado: hipotension"
    elif 90 <= sistolica <= 120 and 60 <= diastolica <= 80:
        return "Estado: normal"
    else:
        return "Estado: hipertension"

# Parámetros de detección de la presión
VALOR_MAXIMO_SENSOR = 122.35
UMBRAL_ESTABILIDAD = 0.5
TIEMPO_ESTABILIZACION = 2
VALOR_MINIMO_DESINFLADO = 14

# Iniciar recolección de datos
datos_presion = []
tiempos = []
estabilizado = False
tiempo_inicio_estabilizacion = None
inicio_medicion = time.time()

enviar_a_arduino("BIENVENIDO :)")

while True:
    if ser.in_waiting:
        dato = ser.readline().decode('latin-1').strip()

        try:
            valor = float(dato)
            tiempo_actual = time.time() - inicio_medicion
            datos_presion.append(valor)
            tiempos.append(tiempo_actual)

            if not estabilizado and valor >= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                if tiempo_inicio_estabilizacion is None:
                    tiempo_inicio_estabilizacion = tiempo_actual
                    enviar_a_arduino("Comenzando a inflar...")
                elif tiempo_actual - tiempo_inicio_estabilizacion >= TIEMPO_ESTABILIZACION:
                    estabilizado = True
                    enviar_a_arduino("Valor máximo estabilizado.")

            if estabilizado and valor <= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                break

        except ValueError as e:
            print(f"Error al convertir el dato: {e}")

enviar_a_arduino("Desinflando...")
while True:
    if ser.in_waiting:
        dato = ser.readline().decode('utf-8').strip()
        try:
            valor = float(dato)
            tiempo_actual = time.time() - inicio_medicion
            datos_presion.append(valor)
            tiempos.append(tiempo_actual)

            if valor <= VALOR_MINIMO_DESINFLADO:
                enviar_a_arduino("Desinflado completado.")
                break

        except ValueError as e:
            print(f"Error al convertir el dato: {e}")

# Procesamiento de los datos para la detección de picos
derivada_presion = np.diff(datos_presion) / np.diff(tiempos)
derivada_presion = np.insert(derivada_presion, 0, 0)
picos_derivada, _ = find_peaks(abs(derivada_presion), height=np.std(derivada_presion))

try:
    if tiempo_inicio_estabilizacion is not None:
        picos_derivada = [p for p in picos_derivada if tiempos[p] >= tiempo_inicio_estabilizacion + TIEMPO_ESTABILIZACION]

        if len(picos_derivada) > 0:
            pico_sistolico = picos_derivada[0]
            presion_sistolica = round(datos_presion[pico_sistolico], 2)
            tiempo_pico_sistolico = tiempos[pico_sistolico]
            presion_diastolica = round(presion_sistolica * 0.67, 2)
            diagnostico = diagnostico_oms(presion_sistolica, presion_diastolica)
            mensaje_presiones = f" {presion_sistolica}| {presion_diastolica}|{diagnostico}"
            enviar_a_arduino(mensaje_presiones)
            time.sleep(10)
        else:
            mensaje_error = "No se detectó presión sistólica"
            print(mensaje_error)
            enviar_a_arduino(mensaje_error)

finally:
    ser.close()
