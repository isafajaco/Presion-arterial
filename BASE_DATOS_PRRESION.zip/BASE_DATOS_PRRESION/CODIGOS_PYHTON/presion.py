import serial
import time
import pandas as pd
from scipy.signal import find_peaks, butter, filtfilt
import matplotlib.pyplot as plt

# Configuración de la conexión serial
puerto_serial = 'COM14'  # Asegúrate de usar el puerto correcto
baudrate = 9600
ser = serial.Serial(puerto_serial, baudrate, timeout=1)
time.sleep(2)  # Esperar a que se establezca la conexión

# Nombre del archivo para guardar los datos
nombre_archivo = "datos_presion.csv"

# Captura de datos del puerto serial y escritura en archivo CSV
def capturar_datos(duracion=30):
    # Abrir el archivo en modo 'append'
    with open(nombre_archivo, "a") as file:
        inicio = time.time()
        while time.time() - inicio < duracion:
            if ser.in_waiting:
                line = ser.readline().decode('utf-8').rstrip()
                print(line)  # Para ver los datos en la consola también
                file.write(line + "\n")

# Llamada a la función de captura de datos
capturar_datos(duracion=30)  # Capturar datos por 30 segundos

# Cerrar la conexión serial
ser.close()

# Análisis de los datos capturados
def analizar_datos():
    # Leer los datos del archivo CSV
    df = pd.read_csv(nombre_archivo, header=None, names=['pressure'])
    pressure = df['pressure'].values

    # Aplicar un filtro de suavizado (filtro de Butterworth)
    b, a = butter(N=3, Wn=0.05)
    filtered_pressure = filtfilt(b, a, pressure)

    # Detectar picos - estas podrían ser tus oscilaciones
    peaks, _ = find_peaks(filtered_pressure, distance=20)

    # Visualizar los resultados
    plt.figure(figsize=(14, 7))
    plt.plot(pressure, label='Original')
    plt.plot(filtered_pressure, label='Filtrado', color='red')
    plt.plot(peaks, filtered_pressure[peaks], "x", label='Picos')
    plt.title('Presión arterial y Oscilaciones detectadas')
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Presión (mmHg)')
    plt.legend()
    plt.show()

    # Estimación de presiones
    # Aquí debes agregar la lógica para estimar la presión sistólica y diastólica
    # basándote en los picos detectados

# Llamada a la función de análisis de datos
analizar_datos()
