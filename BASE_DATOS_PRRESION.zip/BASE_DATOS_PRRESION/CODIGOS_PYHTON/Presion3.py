import serial
import time
from scipy.signal import find_peaks, butter, filtfilt
import matplotlib.pyplot as plt
import numpy as np

# Configuración de la conexión Bluetooth
puerto_bluetooth = 'COM14'  # Cambiar al puerto COM correcto
baudrate = 9600
ser = serial.Serial(puerto_bluetooth, baudrate, timeout=1)
time.sleep(2)  # Esperar a que se establezca la conexión

# Leer datos del puerto serial
def leer_datos_serial(umbral_inflado, duracion=36):
    print("Esperando inicio de inflado...")
    datos_presion = []
    cambio_detectado = False

    while not cambio_detectado:
        if ser.in_waiting:
            linea = ser.readline().decode('utf-8').rstrip()
            if linea.isdigit():
                presion_actual = float(linea)
                print(f"Presión actual: {presion_actual} mmHg")
                if len(datos_presion) > 0 and abs(presion_actual - datos_presion[-1]) > umbral_inflado:
                    cambio_detectado = True
                datos_presion.append(presion_actual)

    print("Inflado detectado, capturando datos...")
    inicio = time.time()
    while time.time() - inicio < duracion:
        if ser.in_waiting:
            linea = ser.readline().decode('utf-8').rstrip()
            if linea.isdigit():
                presion_actual = float(linea)
                print(f"Presión durante inflado: {presion_actual} mmHg")
                datos_presion.append(presion_actual)

    return datos_presion

# Capturar datos por una duración determinada
datos_presion = leer_datos_serial(umbral_inflado=5.0, duracion=36)  # Ajustar el umbral y duración según sea necesario

# Cerrar la conexión serial
ser.close()
print("Captura de datos finalizada.")

# Procesar los datos de presión
def procesar_datos_presion(datos_presion):
    if len(datos_presion) < 12:
        print("No hay suficientes datos para el filtrado. Asegúrate de recoger más datos.")
        return None, None

    # Convertir la lista a un array de numpy
    datos_np = np.array(datos_presion)

    # Aplicar un filtro para suavizar la señal
    b, a = butter(N=3, Wn=0.05, btype='low')
    datos_filtrados = filtfilt(b, a, datos_np)

    # Detectar picos y valles para la estimación de presiones
    picos, _ = find_peaks(datos_filtrados, distance=20)
    valles, _ = find_peaks(-datos_filtrados, distance=20)

    # Calcular las presiones estimadas
    presion_sistolica_estimada = np.mean(datos_filtrados[picos])
    presion_diastolica_estimada = np.mean(datos_filtrados[valles])

    return presion_sistolica_estimada, presion_diastolica_estimada

# Ejecutar el procesamiento de los datos y obtener las estimaciones
sistolica, diastolica = procesar_datos_presion(datos_presion)
if sistolica and diastolica:
    print(f"Presión Sistólica Estimada: {sistolica:.2f} mmHg")
    print(f"Presión Diastólica Estimada: {diastolica:.2f} mmHg")
