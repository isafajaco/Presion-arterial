import serial
import time
from scipy.signal import find_peaks, butter, filtfilt
import matplotlib.pyplot as plt
import numpy as np

# Configuración de la conexión Bluetooth
puerto_bluetooth = 'COM14'  # Reemplazar con el puerto COM correcto
baudrate = 9600
ser = serial.Serial(puerto_bluetooth, baudrate, timeout=1)
time.sleep(2)

# Leer datos del puerto serial
def leer_datos_serial(duracion=36):
    print("Comenzando la captura de datos...")
    datos_presion = []
    inicio = time.time()
    while time.time() - inicio < duracion:
        if ser.in_waiting:
            linea = ser.readline().decode('utf-8').rstrip()
            if linea.isdigit():
                datos_presion.append(float(linea))
    return datos_presion

# ... resto del código para procesar y visualizar los datos ...


# Capturar datos por una duración determinada
datos_presion = leer_datos_serial(duracion=120)  # Ajustar la duración según sea necesario

# Cerrar la conexión serial
ser.close()
print("Captura de datos finalizada.")

# Procesar los datos de presión
def procesar_datos_presion(datos_presion):
    if len(datos_presion) < 12:
        print("No hay suficientes datos para el filtrado. Asegúrate de recoger más datos.")
        return None, None

    # Convertir la lista a un array de numpy
    datos_np = np.array(datos_presion)

    # Aplicar un filtro para suavizar la señal
    b, a = butter(N=3, Wn=0.05, btype='low')
    datos_filtrados = filtfilt(b, a, datos_np)

    # Detectar picos y valles para la estimación de presiones
    picos, _ = find_peaks(datos_filtrados, distance=20)
    valles, _ = find_peaks(-datos_filtrados, distance=20)

    # Calcular las presiones estimadas
    presion_sistolica_estimada = np.mean(datos_filtrados[picos])
    presion_diastolica_estimada = np.mean(datos_filtrados[valles])

    # Graficar los datos
    plt.figure(figsize=(10, 5))
    plt.plot(datos_filtrados, label='Presión Filtrada')
    plt.plot(picos, datos_filtrados[picos], 'x', label='Picos (Sistólica)')
    plt.plot(valles, datos_filtrados[valles], 'x', label='Valles (Diastólica)')
    plt.title('Análisis de Presión Arterial')
    plt.xlabel('Muestras')
    plt.ylabel('Presión (mmHg)')
    plt.legend()
    plt.show()

    return presion_sistolica_estimada, presion_diastolica_estimada

# Ejecutar el procesamiento de los datos y obtener las estimaciones
sistolica, diastolica = procesar_datos_presion(datos_presion)
if sistolica and diastolica:
    print(f"Presión Sistólica Estimada: {sistolica:.2f} mmHg")
    print(f"Presión Diastólica Estimada: {diastolica:.2f} mmHg")
