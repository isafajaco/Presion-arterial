import pandas as pd
import numpy as np

datos = {
        "Pacientes":["Paciente 1", "Paciente 2", "Paciente 3", "Paciente 4", "Paciente 5", "Paciente 6"],
        "Sistolica":[120,70,130,150,170,190],
        "Diastolica":[80,50,89,95,110,120]
        }

Data = pd.DataFrame(datos)
print(Data,"\n")

diagnostico = [np.nan] * Data.shape[0]
Data["Diagnostico"] = diagnostico
Data["Diagnostico"] = Data["Diagnostico"].astype(object)

for index, fila in Data.iterrows():
    if fila["Sistolica"] > 180 and fila["Diastolica"] > 110:
        Data.iloc[index,3] = "Crisis de hipertension"

for index, fila in Data.iterrows():
    if (160 <= fila["Sistolica"] <= 180) and (100 <= fila["Diastolica"] <= 110):
        Data.iloc[index,3] = "Hipertension nivel 2"

for index, fila in Data.iterrows():
    if (140 <= fila["Sistolica"] <= 159) and (90 <= fila["Diastolica"] <= 99):
        Data.iloc[index,3] = "Hipertension nivel 1"

for index, fila in Data.iterrows():
    if (121 <= fila["Sistolica"] <= 139) and (81 <= fila["Diastolica"] <= 89):
        Data.iloc[index,3] = "Prehipertension"

for index, fila in Data.iterrows():
    if (80 <= fila["Sistolica"] <= 120) and (60 <= fila["Diastolica"] <= 80):
        Data.iloc[index,3] = "Normal"

for index, fila in Data.iterrows():
    if fila["Sistolica"] < 80 and fila["Diastolica"] < 60:
        Data.iloc[index,3] = "Hipotension"

print(Data)