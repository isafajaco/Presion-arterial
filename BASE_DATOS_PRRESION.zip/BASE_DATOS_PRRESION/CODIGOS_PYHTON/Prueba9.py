import serial
import pandas as pd
import matplotlib.pyplot as plt
import os
import time

# Configura el puerto serial y la velocidad de baudios
ser = serial.Serial('COM14', 9600)  # Cambia a tu puerto correcto

# Función para recolectar datos durante un tiempo determinado
def recolectar_datos(duracion):
    datos = []
    tiempos = []
    start_time = time.time()
    while time.time() - start_time < duracion:
        if ser.in_waiting:
            line = ser.readline()
            try:
                dato = float(line.decode('utf-8').strip())
                datos.append(dato)
                tiempos.append(time.time() - start_time)
            except ValueError:
                print("No se pudo convertir el dato a un valor flotante")
    return tiempos, datos

# Recolecta datos para 3 medidas diferentes
medidas_datos = {}
colores = ['blue', 'green', 'red']
plt.figure(figsize=(10, 5))
longitud_maxima = 0

for i in range(3):
    input(f"Presiona Enter para comenzar la medida {i+1}")
    tiempos, datos = recolectar_datos(10)
    medidas_datos[f'Medida {i+1}'] = datos
    longitud_maxima = max(longitud_maxima, len(datos))

# Extiende las listas para que todas tengan la misma longitud
for key in medidas_datos:
    medidas_datos[key] += [None] * (longitud_maxima - len(medidas_datos[key]))

# Crea un DataFrame para los datos
df = pd.DataFrame(medidas_datos)
df['Tiempo'] = [i * (10 / longitud_maxima) for i in range(longitud_maxima)]
columnas = ['Tiempo'] + [f'Medida {i+1}' for i in range(3)]
df = df[columnas]

# Guarda el DataFrame en un archivo de Excel
desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
ruta_excel = os.path.join(desktop, 'datos_sensor.xlsx')
df.to_excel(ruta_excel, index=False)

# Dibuja la gráfica
for i in range(3):
    plt.plot(df['Tiempo'], df[f'Medida {i+1}'], color=colores[i], linestyle='-', marker='o', markersize=4, label=f'Medida {i+1}')

# Configuración de la gráfica
plt.title('Datos del Sensor en 3 Medidas de 10 Segundos')
plt.xlabel('Tiempo (s)')
plt.ylabel('Valor del Sensor')
plt.grid(True)
plt.legend()
plt.show()

print(f"Datos guardados en {ruta_excel}")
