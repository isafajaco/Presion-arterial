import serial
import time
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
import numpy as np

# Configuración del puerto serial y la velocidad de baudios
PUERTO = 'COM14'  # Cambia esto por el puerto correcto
BAUDIOS = 9600
ser = serial.Serial(PUERTO, BAUDIOS)

# Parámetros de detección de la presión
VALOR_MAXIMO_SENSOR = 114.9
UMBRAL_ESTABILIDAD = 0.1  # Umbral para determinar que la señal se ha estabilizado
VALOR_MINIMO_DESINFLADO = 16

# Iniciar recolección de datos
datos_presion = []
tiempos = []
tiempo_inicial = time.time()
estabilizado = False
medicion_iniciada = False

# Simular la recolección de datos en tiempo real
print("Esperando valor máximo...")

while True:
    if ser.in_waiting:
        try:
            dato = ser.readline().decode('utf-8').strip()
            valor = float(dato)
            tiempo_actual = time.time() - tiempo_inicial
            datos_presion.append(valor)
            tiempos.append(tiempo_actual)

            # Esperar a que el valor llegue al máximo
            if not estabilizado and valor >= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                estabilizado = True
                print("Valor máximo detectado.")

            # Comenzar la medición cuando se estabiliza en el valor máximo
            if estabilizado and not medicion_iniciada:
                medicion_iniciada = True
                print("Comenzando la recolección de datos...")

            # Finalizar la recolección cuando la presión desciende a 16
            if medicion_iniciada and valor <= VALOR_MINIMO_DESINFLADO:
                print("Bomba desinflada, finalizando la recolección de datos...")
                break

        except UnicodeDecodeError:
            print("Error de decodificación de datos, ignorando...")
        except ValueError:
            print("Dato no es un flotante, ignorando...")

# Cierra el puerto serial
ser.close()

# Función para detectar la presión sistólica (se coloca antes de su uso)
def detectar_pico_sistolico(tiempos, datos_presion):
    picos, _ = find_peaks(datos_presion, height=None)
    if len(picos) > 0:
        # Convertir 'picos' a una lista de valores para indexar 'datos_presion' correctamente
        datos_picos = [datos_presion[pico] for pico in picos]
        indice_pico_sistolico = picos[np.argmax(datos_picos)]
        presion_sistolica = datos_presion[indice_pico_sistolico]
        tiempo_pico_sistolico = tiempos[indice_pico_sistolico]
        return presion_sistolica, tiempo_pico_sistolico
    else:
        return None, None

# Procesar los datos recolectados para detectar la presión sistólica
presion_sistolica, tiempo_pico_sistolico = detectar_pico_sistolico(tiempos, datos_presion)
if presion_sistolica is not None:
    print(f"Presión Sistólica: {presion_sistolica}")
    plt.plot(tiempos, datos_presion, label='Medida Única')
    plt.scatter(tiempo_pico_sistolico, presion_sistolica, color='red')  # Marcar el pico sistólico
else:
    print("No se pudo detectar la presión sistólica en esta medición.")

# Configura y muestra la gráfica
plt.xlabel('Tiempo (s)')
plt.ylabel('Presión')
plt.title('Medición de Presión')
plt.legend()
plt.grid(True)
plt.show()

