import serial
import time
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import find_peaks

# Configuración del puerto serial y la velocidad de baudios
PUERTO = 'COM14'  # Asegúrate de cambiar esto por el puerto correcto
BAUDIOS = 9600
ser = serial.Serial(PUERTO, BAUDIOS)

# Parámetros de detección de la presión
UMBRAL_CAMBIO = 0.5
TIEMPO_PARA_CAMBIO = 1.2  # El tiempo durante el cual se espera un cambio drástico
DURACION_MEDIDA = 38

# Procesamiento de los datos en tiempo real
def procesar_datos_presion(datos_presion):
    # Aquí deberías aplicar cualquier filtrado o procesamiento adicional necesario
    datos_np = np.array(datos_presion)
    picos, _ = find_peaks(datos_np, distance=30)  # distance debe ajustarse según la tasa de muestreo

    if len(picos) > 0:
        presion_sistolica = datos_np[picos[0]]
        tiempo_pico_sistolico = picos[0]
        return presion_sistolica, tiempo_pico_sistolico
    else:
        return None, None

# Iniciar recolección de datos
mediciones = []
presiones_sistolicas = []

for i in range(1, 4):
    print(f"Iniciando medición {i}...")
    datos_presion = []
    tiempo_inicial = time.time()

    # Simular la recolección de datos en tiempo real
    while (time.time() - tiempo_inicial) < DURACION_MEDIDA:
        if ser.in_waiting:
            dato = ser.readline().decode('utf-8').strip()
            try:
                valor = float(dato)
                datos_presion.append(valor)
            except ValueError:
                print("Dato no es un flotante, ignorando...")

    # Procesar los datos recolectados para detectar la presión sistólica
    presion_sistolica, tiempo_pico_sistolico = procesar_datos_presion(datos_presion)
    if presion_sistolica is not None:
        print(f"Presión Sistólica Medición {i}: {presion_sistolica}")
        presiones_sistolicas.append(presion_sistolica)
        plt.plot(datos_presion, label=f'Medida {i}')
        plt.scatter(tiempo_pico_sistolico, presion_sistolica, color='red')  # Marcar el pico sistólico
    else:
        print("No se pudo detectar la presión sistólica en esta medición.")
        presiones_sistolicas.append(None)

# Cierra el puerto serial
ser.close()

# Configura y muestra la gráfica
plt.xlabel('Tiempo (s)')
plt.ylabel('Presión')
plt.title('Medición de Presión')
plt.legend()
plt.grid(True)
plt.show()
