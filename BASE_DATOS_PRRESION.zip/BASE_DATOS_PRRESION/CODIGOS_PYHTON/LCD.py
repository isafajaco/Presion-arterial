import serial
import time
import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import find_peaks
import tkinter as tk
from threading import Thread

# Configuración del puerto serial y la velocidad de baudios
PUERTO = 'COM14'
BAUDIOS = 9600
ser = serial.Serial(PUERTO, BAUDIOS, timeout=1)

# Parámetros de detección de la presión
VALOR_MAXIMO_SENSOR = 132.93
UMBRAL_ESTABILIDAD = 0.5
TIEMPO_ESTABILIZACION = 5
VALOR_MINIMO_DESINFLADO = 15

datos_presion = []
tiempos = []
estabilizado = False
tiempo_inicio_estabilizacion = None

# Función para actualizar la interfaz gráfica simulando el LCD
def actualizar_lcd(mensaje):
    lcd_display.config(text=mensaje)
    root.update()

# Función para leer los datos del puerto serial
def leer_puerto():
    global estabilizado, tiempo_inicio_estabilizacion, datos_presion, tiempos
    tiempo_inicial = time.time()
    actualizar_lcd("Bienvenido")

    while True:
        if ser.in_waiting:
            dato = ser.readline().decode('utf-8').strip()
            try:
                valor = float(dato)
                tiempo_actual = time.time() - tiempo_inicial
                datos_presion.append(valor)
                tiempos.append(tiempo_actual)

                # Actualizar mensajes en la pantalla LCD virtual
                if not estabilizado and valor >= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                    if tiempo_inicio_estabilizacion is None:
                        tiempo_inicio_estabilizacion = tiempo_actual
                        actualizar_lcd("Comenzando a inflar...")
                    elif tiempo_actual - tiempo_inicio_estabilizacion >= TIEMPO_ESTABILIZACION:
                        estabilizado = True
                        actualizar_lcd("Desinflando...")
                elif estabilizado and valor <= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                    if valor <= VALOR_MINIMO_DESINFLADO:
                        actualizar_lcd("Desinflado completado.")
                        break
            except ValueError:
                actualizar_lcd("Error en la lectura")

    # Cerrar el puerto serial
    ser.close()

    # Calcular y mostrar la presión
    calcular_presion()

# Función para calcular y mostrar la presión
def calcular_presion():
    # Cálculo de la presión
    derivada_presion = np.diff(datos_presion) / np.diff(tiempos)
    derivada_presion = np.insert(derivada_presion, 0, 0)
    picos_derivada, _ = find_peaks(abs(derivada_presion), height=np.std(derivada_presion))
    picos_derivada = [p for p in picos_derivada if tiempos[p] >= tiempo_inicio_estabilizacion + TIEMPO_ESTABILIZACION]

    if len(picos_derivada) > 0:
        pico_sistolico = picos_derivada[0]
        presion_sistolica = datos_presion[pico_sistolico]
        presion_diastolica = presion_sistolica * 0.67
        actualizar_lcd(f"Sistolica: {presion_sistolica:.2f} mmHg\nDiastolica: {presion_diastolica:.2f} mmHg")
    else:
        actualizar_lcd("No se detecto presion")

    # Graficar los resultados
    plt.figure(figsize=(10, 6))
    plt.plot(tiempos, datos_presion, label='Medida durante desinflado', color='blue')
    if len(picos_derivada) > 0:
        plt.scatter(tiempos[pico_sistolico], presion_sistolica, color='red', label='Pico Sistólico')
    plt.title('Medición de Presión')
    plt.xlabel('Tiempo (s)')
    plt.ylabel('Presión (mmHg)')
    plt.legend()
    plt.grid(True)
    plt.show()

# Interfaz gráfica
root = tk.Tk()
root.title("Simulación LCD 16x2")
lcd_display = tk.Label(root, text=" " * 16, font=("Courier", 18), bg="black", fg="white")
lcd_display.pack()

# Ejecutar la lectura del puerto en un hilo separado
thread = Thread(target=leer_puerto)
thread.start()

root.mainloop()
