import serial
import time
import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import find_peaks

# Configuración del puerto serial y la velocidad de baudios
PUERTO = 'COM14'  # Ajusta este valor según el puerto en el que está conectado tu Arduino
BAUDIOS = 9600
ser = serial.Serial(PUERTO, BAUDIOS, timeout=1)

# Función para enviar mensajes al Arduino
def enviar_a_arduino(mensaje):
    ser.write(f"{mensaje}\n".encode())

# Función para enviar mensajes divididos (para múltiples líneas)
def enviar_mensaje_dividido(mensaje, retardo=0.5):
    partes = mensaje.split('\n')
    for parte in partes:
        enviar_a_arduino(parte)
        time.sleep(retardo)

# Parámetros de detección de la presión
VALOR_MAXIMO_SENSOR = 122.35
UMBRAL_ESTABILIDAD = 0.5
TIEMPO_ESTABILIZACION = 2
VALOR_MINIMO_DESINFLADO = 14

# Iniciar recolección de datos
datos_presion = []
tiempos = []
estabilizado = False
tiempo_inicio_estabilizacion = None
inicio_medicion = time.time()

enviar_mensaje_dividido("BIENVENIDO :)")

while True:
    if ser.in_waiting:
        dato = ser.readline().decode('utf-8').strip()
        try:
            valor = float(dato)
            tiempo_actual = time.time() - inicio_medicion
            datos_presion.append(valor)
            tiempos.append(tiempo_actual)

            if not estabilizado and valor >= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                if tiempo_inicio_estabilizacion is None:
                    tiempo_inicio_estabilizacion = tiempo_actual
                    enviar_mensaje_dividido("Comenzando a inflar...")
                elif tiempo_actual - tiempo_inicio_estabilizacion >= TIEMPO_ESTABILIZACION:
                    estabilizado = True
                    enviar_mensaje_dividido("Valor máximo estabilizado.")

            if estabilizado and valor <= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                break

        except ValueError as e:
            print(f"Error al convertir el dato: {e}")

enviar_mensaje_dividido("Desinflando...")
while True:
    if ser.in_waiting:
        dato = ser.readline().decode('utf-8').strip()
        try:
            valor = float(dato)
            tiempo_actual = time.time() - inicio_medicion
            datos_presion.append(valor)
            tiempos.append(tiempo_actual)

            if valor <= VALOR_MINIMO_DESINFLADO:
                enviar_mensaje_dividido("Desinflado completado.")
                break

        except ValueError as e:
            print(f"Error al convertir el dato: {e}")

# Procesamiento de los datos para la detección de picos
derivada_presion = np.diff(datos_presion) / np.diff(tiempos)
derivada_presion = np.insert(derivada_presion, 0, 0)
picos_derivada, _ = find_peaks(abs(derivada_presion), height=np.std(derivada_presion))

try:
    if tiempo_inicio_estabilizacion is not None:
        picos_derivada = [p for p in picos_derivada if tiempos[p] >= tiempo_inicio_estabilizacion + TIEMPO_ESTABILIZACION]

        if len(picos_derivada) > 0:
            pico_sistolico = picos_derivada[0]
            presion_sistolica = datos_presion[pico_sistolico]
            tiempo_pico_sistolico = tiempos[pico_sistolico]
            mensaje_presion = f"Presión sistólica:\n{presion_sistolica:.2f} mmHg"
            print(mensaje_presion)
            enviar_mensaje_dividido(mensaje_presion)
            presion_diastolica = presion_sistolica * 0.67
            mensaje_diastolica = f"Presión diastólica:\n{presion_diastolica:.2f} mmHg"
            print(mensaje_diastolica)
            enviar_mensaje_dividido(mensaje_diastolica)
        else:
            mensaje_error = "No se detectó presión sistólica"
            print(mensaje_error)
            enviar_mensaje_dividido(mensaje_error)
finally:
    ser.close()

# Graficar los resultados
plt.figure(figsize=(10, 6))
plt.plot(tiempos, datos_presion, label='Medida durante desinflado', color='blue')
if len(picos_derivada) > 0:
    plt.scatter(tiempo_pico_sistolico, presion_sistolica, color='red', label='Pico Sistólico')
plt.title('Medición de Presión')
plt.xlabel('Tiempo (s)')
plt.ylabel('Presión (mmHg)')
plt.legend()
plt.grid(True)
plt.show()
