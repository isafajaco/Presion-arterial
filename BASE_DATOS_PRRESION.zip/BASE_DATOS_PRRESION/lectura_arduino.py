# pip install pyserial

import serial

# Configura el puerto serie
puerto_serie = serial.Serial('COMX', 9600)  # Reemplaza 'COMX' con el nombre del puerto USB de tu Arduino

# Abre un archivo para almacenar los datos
archivo = open('datos_sensor.csv', 'w')

try:
    while True:
        # Lee datos del puerto serie
        datos = puerto_serie.readline().decode().strip()

        # Almacena los datos en el archivo
        archivo.write(datos + '\n')

        # Muestra los datos en la consola
        print(datos)

except KeyboardInterrupt:
    print("Lectura detenida por el usuario.")

finally:
    archivo.close()
    puerto_serie.close()
