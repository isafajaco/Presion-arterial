import serial
import time
import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import butter, filtfilt, find_peaks

# Configuración del puerto serial y la velocidad de baudios
PUERTO = 'COM14'  # Cambia esto por el puerto correcto
BAUDIOS = 9600
ser = serial.Serial(PUERTO, BAUDIOS, timeout=1)

# Parámetros de detección de la presión
VALOR_MAXIMO_SENSOR = 114.9
UMBRAL_ESTABILIDAD = 0.5  # Ajustar según sea necesario
TIEMPO_ESTABILIZACION = 5  # segundos, ajustar según sea necesario
VALOR_MINIMO_DESINFLADO = 16

# Iniciar recolección de datos
datos_presion = []
tiempos = []
estabilizado = False
tiempo_inicio_estabilizacion = None

print("Esperando valor máximo...")

while True:
    dato = ser.readline().decode('utf-8').strip()
    if dato:
        try:
            valor = float(dato)
            tiempo_actual = time.time()
            datos_presion.append(valor)
            tiempos.append(tiempo_actual)

            # Detectar cuando el valor se estabiliza en el máximo
            if not estabilizado and valor >= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                if tiempo_inicio_estabilizacion is None:
                    tiempo_inicio_estabilizacion = tiempo_actual
                elif tiempo_actual - tiempo_inicio_estabilizacion >= TIEMPO_ESTABILIZACION:
                    estabilizado = True
                    print("Valor máximo estabilizado. ")

            # Asegurarse de que no se comience a detectar el pico hasta que no se haya desinflado suficiente
            if estabilizado and valor <= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                break

        except ValueError as e:
            print(f"Error al convertir el dato: {e}")

# Asumiendo que la presión ha comenzado a disminuir, continuamos recolectando datos
print("Desinflando...")
while True:
    dato = ser.readline().decode('utf-8').strip()
    if dato:
        try:
            valor = float(dato)
            tiempo_actual = time.time()
            datos_presion.append(valor)
            tiempos.append(tiempo_actual)

            if valor <= VALOR_MINIMO_DESINFLADO:
                print("Desinflado completado.")
                break
        except ValueError as e:
            print(f"Error al convertir el dato: {e}")

ser.close()  # Cerrar el puerto serial después de la recolección de datos

# Aquí aplicamos un filtro de Butterworth para suavizar la señal
b, a = butter(N=3, Wn=0.05, btype='low')
datos_filtrados = filtfilt(b, a, datos_presion)

# Ahora detectamos los picos con la señal filtrada
picos, _ = find_peaks(datos_filtrados, prominence=1)  # Ajusta la prominencia si es necesario
picos = [p for p in picos if tiempos[p] >= (tiempo_inicio_estabilizacion + TIEMPO_ESTABILIZACION)]  # Filtramos los picos después del desinflado

# Verificar si se encontraron picos en la fase de desinflado
if len(picos) > 0:
    pico_sistolico = picos[0]  # Tomamos el primer pico como la presión sistólica
    presion_sistolica = datos_filtrados[pico_sistolico]
    tiempo_pico_sistolico = tiempos[pico_sistolico]
    print(f"Presión Sistólica detectada: {presion_sistolica:.2f} mmHg en el tiempo {tiempo_pico_sistolico:.2f} s")
else:
    print("No se pudo detectar la presión sistólica en esta medición.")

# Graficar los resultados
plt.figure(figsize=(10, 6))
plt.plot(tiempos, datos_filtrados, label='Medida durante desinflado', color='blue')
if len(picos) > 0:
    plt.scatter(tiempo_pico_sistolico, presion_sistolica, color='red', label='Pico Sistólico')
plt.title('Medición de Presión')
plt.xlabel('Tiempo (s)')
plt.ylabel('Presión (mmHg)')
plt.legend()
plt.grid(True)
plt.show()
