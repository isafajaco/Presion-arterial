import serial
import time
import matplotlib.pyplot as plt
import numpy as np
from scipy.signal import find_peaks

# Configuración del puerto serial y la velocidad de baudios
PUERTO = 'COM14'
BAUDIOS = 9600
ser = serial.Serial(PUERTO, BAUDIOS, timeout=1)

# Parámetros de detección de la presión
VALOR_MAXIMO_SENSOR = 139.03
UMBRAL_ESTABILIDAD = 0.5
TIEMPO_ESTABILIZACION = 5
VALOR_MINIMO_DESINFLADO = 17

# Iniciar recolección de datos
datos_presion = []
tiempos = []
estabilizado = False
tiempo_inicio_estabilizacion = None

print("Esperando valor máximo...")

while True:
    dato = ser.readline().decode('utf-8').strip()
    if dato:
        try:
            valor = float(dato)
            tiempo_actual = time.time()
            datos_presion.append(valor)
            tiempos.append(tiempo_actual)

            # Detectar cuando el valor se estabiliza en el máximo
            if not estabilizado and valor >= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                if tiempo_inicio_estabilizacion is None:
                    tiempo_inicio_estabilizacion = tiempo_actual
                elif tiempo_actual - tiempo_inicio_estabilizacion >= TIEMPO_ESTABILIZACION:
                    estabilizado = True
                    print("Valor máximo estabilizado.")

            # Asegurarse de que no se comience a detectar el pico hasta que no se haya desinflado suficiente
            if estabilizado and valor <= VALOR_MAXIMO_SENSOR - UMBRAL_ESTABILIDAD:
                break

        except ValueError as e:
            print(f"Error al convertir el dato: {e}")

# Asumiendo que la presión ha comenzado a disminuir, continuamos recolectando datos
print("Desinflando...")
while True:
    dato = ser.readline().decode('utf-8').strip()
    if dato:
        try:
            valor = float(dato)
            tiempo_actual = time.time()
            datos_presion.append(valor)
            tiempos.append(tiempo_actual)

            if valor <= VALOR_MINIMO_DESINFLADO:
                print("Desinflado completado.")
                break
        except ValueError as e:
            print(f"Error al convertir el dato: {e}")

ser.close()

# Calculamos la derivada de la señal para detectar cambios bruscos en la pendiente
derivada_presion = np.diff(datos_presion) / np.diff(tiempos)
derivada_presion = np.insert(derivada_presion, 0, 0)  # Añadimos un 0 al principio para mantener el tamaño

# Detectamos los picos en la derivada
picos_derivada, _ = find_peaks(abs(derivada_presion), height=np.std(derivada_presion))

# Filtramos los picos que ocurran después del desinflado
picos_derivada = [p for p in picos_derivada if tiempos[p] >= tiempo_inicio_estabilizacion + TIEMPO_ESTABILIZACION]

# Asumimos que el primer pico es la presión sistólica y el segundo la presión diastólica
if len(picos_derivada) > 1:
    pico_sistolico = picos_derivada[0]  # El primer pico como la presión sistólica
    presion_sistolica = datos_presion[pico_sistolico]
    tiempo_pico_sistolico = tiempos[pico_sistolico]
    print(f"Tu presión sistólica es: {presion_sistolica:.2f} mmHg")

    pico_diastolico = picos_derivada[1]  # El segundo pico como la presión diastólica
    presion_diastolica = datos_presion[pico_diastolico]
    tiempo_pico_diastolico = tiempos[pico_diastolico]
    print(f"Tu presión diastólica es: {presion_diastolica:.2f} mmHg")
else:
    print("No se pudieron detectar los picos sistólico y diastólico en esta medición.")

# Graficar los resultados
plt.figure(figsize=(10, 6))
plt.plot(tiempos, datos_presion, label='Medida durante desinflado', color='blue')
if len(picos_derivada) > 1:
    plt.scatter(tiempo_pico_sistolico, presion_sistolica, color='red', label='Pico Sistólico')
    plt.scatter(tiempo_pico_diastolico, presion_diastolica, color='green', label='Pico Diastólico')
plt.title('Medición de Presión')
plt.xlabel('Tiempo (s)')
plt.ylabel('Presión (mmHg)')
plt.legend()
plt.grid(True)
plt.show()
