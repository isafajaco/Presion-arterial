import serial
import pandas as pd
import matplotlib.pyplot as plt
import os
import time

# Configura el puerto serial y la velocidad de baudios
ser = serial.Serial('COM14', 9600)  # Cambia a tu puerto correcto

# Función para recolectar datos durante un tiempo determinado
def recolectar_datos(duracion):
    datos = []
    tiempos = []
    start_time = time.time()
    while time.time() - start_time < duracion:
        if ser.in_waiting:
            line = ser.readline()
            try:
                dato = float(line.decode('utf-8').strip())
                datos.append(dato)
                tiempos.append(time.time() - start_time)
            except ValueError:
                print("No se pudo convertir el dato a un valor flotante")
    return tiempos, datos

# Recolecta datos para 3 medidas diferentes
medidas_datos = {}
medidas_tiempos = {}
colores = ['blue', 'green', 'red']
plt.figure(figsize=(10, 5))
longitud_maxima = 0

for i in range(3):
    input(f"Presiona Enter para comenzar la medida {i+1}")
    tiempos, datos = recolectar_datos(10)
    medidas_datos[f'Medida {i+1}'] = datos
    medidas_tiempos[f'Tiempos {i+1}'] = tiempos
    longitud_maxima = max(longitud_maxima, len(datos))

# Asegurarse de que todas las listas de tiempos y datos tienen la misma longitud
for i in range(3):
    faltantes = longitud_maxima - len(medidas_datos[f'Medida {i+1}'])
    medidas_datos[f'Medida {i+1}'] += [None] * faltantes
    ultimo_tiempo = medidas_tiempos[f'Tiempos {i+1}'][-1] if medidas_tiempos[f'Tiempos {i+1}'] else 0
    medidas_tiempos[f'Tiempos {i+1}'] += [ultimo_tiempo + j * (tiempos[-1] / longitud_maxima) for j in range(1, faltantes + 1)]

# Crea el DataFrame y el archivo Excel
df = pd.DataFrame(medidas_datos)
desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')
ruta_excel = os.path.join(desktop, 'datos_sensor.xlsx')
df.to_excel(ruta_excel, index=False)

# Dibuja la gráfica
for i in range(3):
    plt.plot(medidas_tiempos[f'Tiempos {i+1}'], medidas_datos[f'Medida {i+1}'], color=colores[i], linestyle='-', marker='o', markersize=4, label=f'Medida {i+1}')

# Configuración de la gráfica
plt.title('Datos del Sensor en 3 Medidas de 10 Segundos')
plt.xlabel('Tiempo (s)')
plt.ylabel('Valor del Sensor')
plt.grid(True)
plt.legend()
plt.show()

print(f"Datos guardados en {ruta_excel}")
