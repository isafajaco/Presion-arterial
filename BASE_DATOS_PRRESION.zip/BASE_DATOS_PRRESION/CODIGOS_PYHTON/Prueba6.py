import serial
import pandas as pd
import os
import time

# Configura el puerto serial y la velocidad de baudios
ser = serial.Serial('COM14', 9600)  # Cambia a tu puerto correcto

# Función para recolectar datos durante un tiempo determinado
def recolectar_datos(duracion):
    datos = []
    tiempos = []
    start_time = time.time()
    while time.time() - start_time < duracion:
        if ser.in_waiting:
            line = ser.readline()
            try:
                # Asegúrate de que la línea sea un número
                if line.strip().isdigit():
                    dato = float(line.decode('utf-8').strip())
                    datos.append(dato)
                    tiempos.append(time.time() - start_time)
            except ValueError as e:
                print(f"Error al convertir los datos: {e}")

    return tiempos, datos

# Recolecta datos para 3 medidas diferentes
medidas = {}
for i in range(3):
    input(f"Presiona Enter para comenzar la medida {i+1}")
    tiempos, datos = recolectar_datos(10)
    medidas[f'Medida {i+1}'] = datos

# Cierra el puerto serial
ser.close()

# Guarda los datos en un DataFrame de pandas
df = pd.DataFrame(medidas)

# Consigue la ruta del escritorio del usuario actual
desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')

# Ruta para guardar el archivo en el escritorio
ruta_excel = os.path.join(desktop, 'datos_sensor.xlsx')

# Guarda el DataFrame en un archivo de Excel
df.to_excel(ruta_excel, index=False)

print(f"Datos guardados en {ruta_excel}")
