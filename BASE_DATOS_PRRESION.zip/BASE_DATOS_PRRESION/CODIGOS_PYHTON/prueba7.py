import serial
import pandas as pd
import os
import time

# Configura el puerto serial y la velocidad de baudios
ser = serial.Serial('COM14', 9600)  # Cambia a tu puerto correcto

# Función para recolectar datos durante un tiempo determinado
def recolectar_datos(duracion):
    datos = []
    start_time = time.time()
    while time.time() - start_time < duracion:
        if ser.in_waiting:
            line = ser.readline().decode('utf-8').strip()
            if "MAX_VALUE_REACHED" in line:
                print("Valor máximo alcanzado, comenzando la recolección de datos...")
                break  # Sale del bucle cuando Arduino indica que ha alcanzado el valor máximo
            else:
                print("Esperando el valor máximo...")
                time.sleep(1)  # Espera un poco antes de volver a comprobar

    start_time = time.time()  # Reinicia el contador de tiempo
    while time.time() - start_time < duracion:
        if ser.in_waiting:
            line = ser.readline()
            try:
                dato = float(line.decode('utf-8').strip())
                datos.append(dato)
            except ValueError:
                print("No se pudo convertir el dato a un valor flotante")
    return datos

# Recolecta datos para 3 medidas diferentes
medidas = {}
for i in range(1, 4):
    print(f"Comenzando la medida {i}")
    datos = recolectar_datos(10)  # Llama a la función para recolectar datos después de que se alcance el valor máximo
    medidas[f'Medida {i}'] = datos

# Cierra el puerto serial
ser.close()

# Cierra el puerto serial
ser.close()

# Consigue la ruta del escritorio del usuario actual
desktop = os.path.join(os.path.join(os.environ['USERPROFILE']), 'Desktop')

# Ruta para guardar el archivo en el escritorio
ruta_excel = os.path.join(desktop, 'datos_sensor.xlsx')

# Guarda los datos en un DataFrame de pandas
df = pd.DataFrame.from_dict(medidas, orient='index').transpose()

# Guarda el DataFrame en un archivo de Excel
df.to_excel(ruta_excel, index=False)

print(f"Datos guardados en {ruta_excel}")
